
import torch
import torch.nn as nn
from torchvision import models, transforms
from PIL import Image
import io

NUM_CLASSES = 4  # Change this if needed

def model_fn(model_dir):
    model = models.resnet18(weights=None)
    model.fc = nn.Linear(model.fc.in_features, NUM_CLASSES)
    model.load_state_dict(torch.load(f"{model_dir}/model.pth", map_location=torch.device('cpu')))
    model.eval()
    return model

def input_fn(request_body, content_type='application/x-image'):
    if content_type == 'application/x-image':
        image = Image.open(io.BytesIO(request_body)).convert("RGB")
        transform = transforms.Compose([
            transforms.Resize((224, 224)),
            transforms.ToTensor(),
        ])
        return transform(image).unsqueeze(0)
    raise ValueError("Unsupported content type: {}".format(content_type))

def predict_fn(input_data, model):
    with torch.no_grad():
        output = model(input_data)
    return torch.argmax(output, dim=1).item()
